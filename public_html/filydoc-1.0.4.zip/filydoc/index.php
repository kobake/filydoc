<?php
require_once('filydoc-core/core.php');
