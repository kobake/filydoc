<!-- Sitename: Filydoc -->
<!-- Copyright: Copyright 2014 <a href="https://github.com/kobake">kobake</a> -->
<!-- keywords: download, top -->

## Filydoc
Simple file document system.

## GitHub repository
https://github.com/kobake/filydoc

## Download
- <a href="/filydoc-1.0.3.tgz" target="_top">filydoc-1.0.3.tgz</a>
- <a href="/filydoc-1.0.3.zip" target="_top">filydoc-1.0.3.zip</a>

