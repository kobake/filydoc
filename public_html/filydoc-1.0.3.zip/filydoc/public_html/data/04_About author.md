<!-- keywords: future, markdoc, flatdoc, ditto, 類似, similar, folder, search, quick, filter -->
## Author
kobake, in Japan.

- https://github.com/kobake
- https://twitter.com/kobayan_tokyo
- http://clock-up.jp/
- kobake@users.sourceforge.net
