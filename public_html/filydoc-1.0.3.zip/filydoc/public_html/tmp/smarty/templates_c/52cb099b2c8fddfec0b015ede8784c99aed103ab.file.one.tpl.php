<?php /* Smarty version Smarty-3.1.13, created on 2014-07-07 03:17:33
         compiled from "/home/sites/filydoc/filydoc.net/public_html/filydoc-core/templates/one.tpl" */ ?>
<?php /*%%SmartyHeaderCode:206091606853b992bd6ff903-82143521%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52cb099b2c8fddfec0b015ede8784c99aed103ab' => 
    array (
      0 => '/home/sites/filydoc/filydoc.net/public_html/filydoc-core/templates/one.tpl',
      1 => 1404670376,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '206091606853b992bd6ff903-82143521',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'metas' => 0,
    'body' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b992bd7875f0_66962596',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b992bd7875f0_66962596')) {function content_53b992bd7875f0_66962596($_smarty_tpl) {?><!DOCTYPE html>
<html ng-app="myApp">
<head>
	<meta charset="UTF-8" />
	<!-- 漢字 -->
	<title><?php echo $_smarty_tpl->tpl_vars['metas']->value['headtitle'];?>
</title>
	<?php if ($_smarty_tpl->tpl_vars['metas']->value['description']!=''){?>
		<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['metas']->value['description'];?>
" />
	<?php }?>

	<!-- CSS -->
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" />

	<!-- <link rel="stylesheet/less" type="text/css" href="<?php echo getWebCoreDir();?>
/css/simple-sidebar.less" /> -->
	<link rel="stylesheet" href="<?php echo getWebCoreDir();?>
/css/simple-sidebar.css" />
</head>
<body>
	<div id="wrapper">
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<!-- 本体 -->
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<div id="page-content-wrapper"><div><div id="right-wrapper">
			<section id="content-section">
				<div class="content-header">
					<h1>
						<?php echo $_smarty_tpl->tpl_vars['metas']->value['h1title'];?>

					</h1>
				</div>
				<div class="page-content inset">
					<!-- 内部目次 -->
					<div class="toc">
						<div class="toc-title">
							Contents
						</div>
						<div class="toc-content">
							<ol>
							</ol>
						</div>
					</div>
					<div class="toc-dummy">
					</div>
					<!-- 本体 -->
					<?php echo $_smarty_tpl->tpl_vars['body']->value;?>

				</div>
				
				<?php echo getPageFoot();?>

			</section>
		</div></div></div>
	</div>
	<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/1.7.0/less.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

	<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
	<!-- Script for social -->
	<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
	<!-- Google+ social button -->
	

	<!-- Tumblr social button -->
	

</body>
</html>
<?php }} ?>