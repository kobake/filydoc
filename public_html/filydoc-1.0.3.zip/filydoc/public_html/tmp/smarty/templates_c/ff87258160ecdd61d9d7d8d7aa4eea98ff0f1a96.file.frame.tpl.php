<?php /* Smarty version Smarty-3.1.13, created on 2014-07-07 03:17:32
         compiled from "/home/sites/filydoc/filydoc.net/public_html/filydoc-core/templates/frame.tpl" */ ?>
<?php /*%%SmartyHeaderCode:113276717753b992bcb72b49-71476876%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff87258160ecdd61d9d7d8d7aa4eea98ff0f1a96' => 
    array (
      0 => '/home/sites/filydoc/filydoc.net/public_html/filydoc-core/templates/frame.tpl',
      1 => 1404670376,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '113276717753b992bcb72b49-71476876',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'metas' => 0,
    'dirs_json' => 0,
    'body' => 0,
    'items_html' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b992bcc26a34_36312323',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b992bcc26a34_36312323')) {function content_53b992bcc26a34_36312323($_smarty_tpl) {?><!DOCTYPE html>
<html ng-app="myApp">
<head>
	<meta charset="UTF-8" />
	<!-- 漢字 -->
	<title><?php echo getPageTitle();?>
</title>
	<?php if ($_smarty_tpl->tpl_vars['metas']->value['description']!=''){?>
	<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['metas']->value['description'];?>
" />
	<?php }?>

	<!-- favicon -->
	<link rel="icon" type="image/png" href="/favicon.png" />

	<!-- OGP -->
	<meta property="og:site_name" content="<?php echo getSiteName();?>
" data-webroot="<?php echo getWebRootDir();?>
" />
	<meta property="og:title" content="<?php echo getPageTitle();?>
" />
	<meta property="og:type" content="<?php echo getOgpType();?>
" />
	<meta property="og:url" content="<?php echo getPageUrl();?>
" />
	<meta property="og:image" content="<?php echo getSiteUrl();?>
ogp.png" />

	<!-- CSS -->
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" />
	<link rel="stylesheet" href="<?php echo getWebCoreDir();?>
/libs/jquery.treeview/jquery.treeview.css" />

	<!-- <link rel="stylesheet/less" type="text/css" href="<?php echo getWebCoreDir();?>
/css/simple-sidebar.less" /> -->
	<link rel="stylesheet" href="<?php echo getWebCoreDir();?>
/css/simple-sidebar.css" />

	<style type="text/css">
	</style>
</head>
<body>
	<div id="fb-root"></div>
	
	<div id="wrapper">
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<!-- JS解釈 -->
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<script>
			window.menus = <?php echo $_smarty_tpl->tpl_vars['dirs_json']->value;?>
;
		</script>
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<!-- ナビゲーション (上部をナビと呼ぶか左部をナビと呼ぶかは迷いどころである) -->
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<nav class="navbar navbar-default navbar-fixed-top role="navigation">
			<div class="container">
				<!-- Brand -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" rel="home" href="<?php echo getWebRootDir();?>
/" title="<?php echo getSiteName();?>
 top" target="_self"><?php echo getSiteName();?>
</a>
				</div>

				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<!-- Search -->
					<div class="col-sm-4 col-md-4" style="width: 300px;" ng-controller="SearchController"> <!-- 右寄せにする場合は pull-right -->
						<form class="navbar-form" role="search" /><!-- method="GET" action="/search"> -->
							<div class="input-group">
								<input type="text" class="form-control" placeholder="Search" name="q" id="search-keyword" ng-model="q">
								<div class="input-group-btn">
									<button class="btn btn-default" type="submit" ng-click="go()"><i class="glyphicon glyphicon-search"></i></button>
								</div>
							</div>
						</form>
					</div>

					<!-- ナビゲーションリンク等 -->
					<!--
						<ul class="nav navbar-nav">
						<li><a href="/all-topics/">/all</a></li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Menu <b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li><a href="#">Settings</a></li>
								<li><a href="#">Logout</a></li>
							</ul>
						</li>
						</ul>
					-->

				</div>
			</div>
		</nav>
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<!-- ナビゲーションより下部の全て -->
		<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
		<div class="clearfix" style="margin-top: 0px;">
			<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
			<!-- 本体 -->
			<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
			<div id="page-content-wrapper">
				<div>
					<div id="right-wrapper">
						<section id="content-section">
							<div class="page-content inset">
								<?php echo $_smarty_tpl->tpl_vars['body']->value;?>

							</div>
						</section>
					</div>
				</div>
				<footer class="footer" id="footer">
					<div class="container">
						<p>
							<?php echo getCopyright();?>

						</p>
						<p>
							Powered by <a href="http://filydoc.net">Filydoc</a>
						</p>
					</div>
				</footer>
			</div>
			<!-- ダミー -->
			<div ng-view></div>
			<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
			<!-- サイドバー -->
			<!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
			<aside id="sidebar-wrapper-out">
				<div id="sidebar-wrapper">

					<div id="treecontrol">
						<div id="control-left">
							<input type="text" placeholder="Filter" name="filter" id="filter" ng-model="filter" />
						</div>
						<div id="control-right">
							<a title="Collapse the entire tree below" href="#"><img src="<?php echo getWebCoreDir();?>
/libs/jquery.treeview/images/minus.gif"><span>ColAll</span></a>
							<a title="Expand the entire tree below" href="#"><img src="<?php echo getWebCoreDir();?>
/libs/jquery.treeview/images/plus.gif"><span>ExpAll</span></a>
						</div>
					</div>

					<div id="tree-box">
						<div><a href="<?php echo getWebRootDir();?>
/"><span>Top</span></a></div>
						<?php echo $_smarty_tpl->tpl_vars['items_html']->value;?>

					</div>
				</div>
			</aside>
		</div>
	</div> <!-- /wrapper -->
	<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/1.7.0/less.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/jquery.mousewheel.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/jquery.cookie/jquery.cookie.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/jquery.treeview/jquery.treeview.js" type="text/javascript"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/angularjs/angular.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/angularjs/angular-resource.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/angularjs/angular-route.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/libs/footerFixed.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/js/tree.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/js/app.js"></script>
	<script src="<?php echo getWebCoreDir();?>
/js/other.js"></script>
	<?php echo getAnalytics();?>


</body>
</html>
<?php }} ?>